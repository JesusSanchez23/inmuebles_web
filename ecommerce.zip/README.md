## App Salón
### Tecnologías utilizadas

- HTML
- CSS




#### Link del sitio web:  https://store.blentoom.com/

![](https://user-images.githubusercontent.com/58642814/156860179-82c913d1-df82-4124-a92f-a6463c547d42.PNG)
